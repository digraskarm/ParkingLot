﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTestProject3
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            ParkingLotManager.ParkingLot myTestParkingLot = new ParkingLotManager.ParkingLot();
            myTestParkingLot.NumOfHatchbacks = 5;
            myTestParkingLot.NumOfSedans = 5;
            myTestParkingLot.NumOfTrucks = 5;

            myTestParkingLot.InitializeParkingLot();

            ParkingLotManager.ParkingSpot spot;

            for (int i = 0; i <= myTestParkingLot.NumOfSedans; i++)
            {
                spot = myTestParkingLot.AssignParkingSpot(new ParkingLotManager.Vehicle { VehicleSize = ParkingLotManager.Size.Sedan });
                Console.WriteLine(spot == null ? "No spot available" : "Assigned spot with size: " + spot.SpotSize);
            }
            Console.Read();
        }
    }
}
