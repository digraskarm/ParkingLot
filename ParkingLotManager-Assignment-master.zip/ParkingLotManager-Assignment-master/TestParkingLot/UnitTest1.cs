﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace TestParkingLot
{
    [TestClass]
    public class UnitTest1
    {
        ParkingLotManager.ParkingLot myTestParkingLot = new ParkingLotManager.ParkingLot();
        ParkingLotManager.ParkingSpot spot;

        [TestInitialize]
        public void Setup()
        {
            myTestParkingLot.NumOfHatchbacks = 5;
            myTestParkingLot.NumOfSedans = 5;
            myTestParkingLot.NumOfTrucks = 5;
            myTestParkingLot.InitializeParkingLot();

        }

        [TestMethod]
        public void ParkingSedanTest()
        {
            for (int i = 0; i <= myTestParkingLot.NumOfSedans; i++)
            {
                spot = myTestParkingLot.AssignParkingSpot(new ParkingLotManager.Vehicle { VehicleSize = ParkingLotManager.Size.Sedan });
                Console.WriteLine(spot == null ? "No spot available" : "Assigned spot with size: " + spot.SpotSize);
            }

        }

        [TestMethod]
        public void ParkingTruckTest()
        {
            for (int i = 0; i <= myTestParkingLot.NumOfTrucks; i++)
            {
                spot = myTestParkingLot.AssignParkingSpot(new ParkingLotManager.Vehicle() { VehicleSize = ParkingLotManager.Size.Truck });
                Console.WriteLine(spot == null ? "No spot available" : "Assigned spot with size: " + spot.SpotSize);
            }

        }

        [TestMethod]
        public void ParkingHatchbacksTest()
        {
            for (int i = 0; i < myTestParkingLot.NumOfHatchbacks; i++)
            {
                spot = myTestParkingLot.AssignParkingSpot(new ParkingLotManager.Vehicle() { VehicleSize = ParkingLotManager.Size.Hatchback });
                Console.WriteLine(spot == null ? "No spot available" : "Assigned spot with size: " + spot.SpotSize);
            }

        }

    }
}
